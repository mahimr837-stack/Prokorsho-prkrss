import { useEffect, useRef, useState } from "react";
import { Layout } from "@/components/layout";

const problem = "দুইটি সমান মানের ভেক্টরের লব্ধির মান কোন অবস্থায় ওদের প্রত্যেকের মানের সমান হতে পারে?";
const steps = [
  "ধরি, প্রথম ভেক্টরের মান = A",
  "দ্বিতীয় ভেক্টরের মান = A (সমান মানের)",
  "লব্ধির মান R = A (শর্ত অনুযায়ী)",
  "ভেক্টর সংযোজনের সূত্র: R² = A² + A² + 2A·A·cos(θ)",
  "R² = A² + A² + 2A² cos(θ)",
  "R² = 2A² + 2A² cos(θ)",
  "এখন R = A, তাই R² = A²",
  "A² = 2A² + 2A² cos(θ)",
  "A² - 2A² = 2A² cos(θ)",
  "-A² = 2A² cos(θ)",
  "cos(θ) = -A²/(2A²) = -1/2",
  "θ = cos⁻¹(-1/2) = 120°",
];
const answer = "θ = 120°";

export function VectorProblem02() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [problemText, setProblemText] = useState("");
  const [solvedSteps, setSolvedSteps] = useState<string[]>([]);
  const [answerText, setAnswerText] = useState("");
  const [running, setRunning] = useState(false);

  function drawDiagram() {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    const w = canvas.width, h = canvas.height, cx = w / 2, cy = h / 2;
    ctx.fillStyle = "#faf8f3"; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#e8dcc8"; ctx.lineWidth = 1;
    for (let i = 0; i < w; i += 30) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke(); }
    for (let i = 0; i < h; i += 30) { ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke(); }
    ctx.strokeStyle = "#8b7355"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(cx, 20); ctx.lineTo(cx, h - 20); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(20, cy); ctx.lineTo(w - 20, cy); ctx.stroke();
    ctx.fillStyle = "#8b7355"; ctx.beginPath(); ctx.arc(cx, cy, 5, 0, Math.PI * 2); ctx.fill();
    const scale = 60;
    function drawVec(ex: number, ey: number, color: string, label: string) {
      ctx.strokeStyle = color; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(ex, ey); ctx.stroke();
      const a = Math.atan2(ey - cy, ex - cx);
      ctx.beginPath(); ctx.moveTo(ex, ey);
      ctx.lineTo(ex - 10 * Math.cos(a - Math.PI/6), ey - 10 * Math.sin(a - Math.PI/6));
      ctx.lineTo(ex - 10 * Math.cos(a + Math.PI/6), ey - 10 * Math.sin(a + Math.PI/6));
      ctx.closePath(); ctx.fillStyle = color; ctx.fill();
      ctx.fillStyle = color; ctx.font = "bold 14px sans-serif"; ctx.fillText(label, ex + 8, ey - 8);
    }
    drawVec(cx + scale, cy, "#3498db", "A");
    const ang2 = 120 * Math.PI / 180;
    drawVec(cx + scale * Math.cos(ang2), cy - scale * Math.sin(ang2), "#27ae60", "A");
    ctx.strokeStyle = "#8b7355"; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, 30, 0, -ang2, true); ctx.stroke();
    ctx.setLineDash([]); ctx.fillStyle = "#8b7355"; ctx.font = "12px sans-serif"; ctx.fillText("120°", cx + 35, cy - 8);
  }

  async function start() {
    if (running) return; setRunning(true);
    setSolvedSteps([]); setAnswerText("");
    let i = 0; const typed: string[] = [];
    const typeP = () => new Promise<void>((res) => { let s = ""; const iv = setInterval(() => { s += problem[s.length]; setProblemText(s); if (s.length === problem.length) { clearInterval(iv); res(); } }, 30); });
    await typeP();
    for (i = 0; i < steps.length; i++) {
      await new Promise<void>((resolve) => {
        let s = "";
        const interval = setInterval(() => {
          s += steps[i][s.length]; typed[i] = s; setSolvedSteps([...typed]);
          if (s.length === steps[i].length) { clearInterval(interval); resolve(); }
        }, 22);
      });
    }
    let a = ""; const iv = setInterval(() => { a += answer[a.length]; setAnswerText(a); if (a.length === answer.length) clearInterval(iv); }, 40);
    setRunning(false);
  }

  function reset() { setRunning(false); setProblemText(""); setSolvedSteps([]); setAnswerText(""); }

  useEffect(() => { drawDiagram(); }, []);
  useEffect(() => { start(); }, []);

  return (
    <Layout>
      <div className="mb-6"><h1 className="text-2xl font-bold">সমান মানের ভেক্টর সমস্যা</h1></div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="flex flex-col gap-4">
          <div className="bg-card border border-border rounded-xl p-5 border-l-4 border-l-amber-700">
            <h2 className="text-xs font-semibold uppercase tracking-widest text-amber-700 mb-3">প্রশ্ন</h2>
            <p className="text-base leading-relaxed text-foreground min-h-[60px]">{problemText}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-5 border-l-4 border-l-amber-500">
            <h2 className="text-xs font-semibold uppercase tracking-widest text-amber-700 mb-3">সমাধান</h2>
            <div className="flex flex-col gap-3">
              {solvedSteps.map((s, i) => (
                <div key={i} className="bg-muted/50 rounded-lg px-4 py-3 text-sm border-l-2 border-amber-300">
                  <span className="font-semibold text-amber-700 mr-2">ধাপ {i + 1}:</span>{s}
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">রেফারেন্স ডায়াগ্রাম</h3>
            <canvas ref={canvasRef} width={350} height={280} className="w-full rounded-lg" />
          </div>
          <div className="rounded-xl p-5 text-center text-white" style={{background:"linear-gradient(135deg,#d4af9f,#b8956a)"}}>
            <h3 className="text-xs font-semibold uppercase tracking-widest mb-2">চূড়ান্ত উত্তর</h3>
            <div className="text-3xl font-light tracking-widest min-h-[40px]">{answerText}</div>
          </div>
          <button onClick={() => { reset(); setTimeout(start, 100); }}
            className="mx-auto px-8 py-3 rounded-full text-sm font-medium text-white transition-all hover:-translate-y-0.5"
            style={{background:"linear-gradient(135deg,#8b7355,#a0937d)"}}>
            🔄 রিসেট করুন
          </button>
        </div>
      </div>
    </Layout>
  );
}
