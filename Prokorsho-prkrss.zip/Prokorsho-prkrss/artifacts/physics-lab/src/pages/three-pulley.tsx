import { Layout } from "@/components/layout";

export function ThreePulley() {
  return (
    <Layout>
      <div className="-mx-4 sm:-mx-6 lg:-mx-8 -my-8 lg:-my-12" style={{ height: "calc(100vh - 64px)" }}>
        <iframe
          src="/sims/three-pulley.html"
          className="w-full h-full border-0"
          title="তিন পুলি সংযোগ সিস্টেম"
        />
      </div>
    </Layout>
  );
}
