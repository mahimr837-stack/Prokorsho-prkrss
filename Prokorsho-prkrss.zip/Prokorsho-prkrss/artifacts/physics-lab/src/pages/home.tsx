import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import {
  FlaskConical,
  ChevronDown,
  ChevronRight,
  BookOpen,
  Beaker,
  MoveRight,
  TrendingUp,
  Maximize2,
  Waves,
  Zap,
  CloudRain,
  Cpu,
  Train,
  Weight,
  GitFork,
  Activity,
  Layers,
  Atom,
  Ruler,
  FlaskRound,
  Leaf,
  Calculator,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type Sim = {
  id: string;
  title: string;
  href: string;
  icon: React.ElementType;
};

type Chapter = {
  id: string;
  number: string;
  title: string;
  english: string;
  sims: Sim[];
};

type Book = {
  id: string;
  title: string;
  subtitle: string;
  lab: string;
  color: string;
  glow: string;
  icon: React.ElementType;
  chapters: Chapter[];
};

const BOOKS: Book[] = [
  {
    id: "book1",
    title: "পদার্থবিজ্ঞান — ১ম পত্র",
    subtitle: "Physics First Paper",
    lab: "পদার্থবিজ্ঞান ল্যাব",
    color: "#f59e42",
    glow: "rgba(245,158,66,0.25)",
    icon: Beaker,
    chapters: [
      {
        id: "ch1-1",
        number: "প্রথম অধ্যায়",
        title: "ভৌতজগৎ ও পরিমাপ",
        english: "Physical World and Measurement",
        sims: [],
      },
      {
        id: "ch1-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "ভেক্টর",
        english: "Vector",
        sims: [
          {
            id: "vector-types",
            title: "ভেক্টরের প্রকারভেদ",
            href: "/vector-types",
            icon: MoveRight,
          },
          {
            id: "vector-addition",
            title: "ভেক্টর যোগ",
            href: "/vector-addition",
            icon: MoveRight,
          },
          {
            id: "vector-components",
            title: "ভেক্টর উপাংশ",
            href: "/vector-components",
            icon: TrendingUp,
          },
          {
            id: "max-min",
            title: "সর্বোচ্চ ও সর্বনিম্ন লব্ধি",
            href: "/max-min-resultant",
            icon: Maximize2,
          },
          {
            id: "rectangular-component",
            title: "লম্বাংশ উপপাদ্য",
            href: "/rectangular-component",
            icon: Zap,
          },
          {
            id: "rain-umbrella",
            title: "বৃষ্টি-ছাতা ভিজ্যুয়ালাইজেশন",
            href: "/rain-umbrella",
            icon: CloudRain,
          },
          {
            id: "relative-velocity-trains",
            title: "আপেক্ষিক বেগ — দুটি ট্রেন",
            href: "/relative-velocity-trains",
            icon: Train,
          },
          {
            id: "vector-problem-01",
            title: "ভেক্টর সমস্যা ০১",
            href: "/vector-problem-01",
            icon: BookOpen,
          },
          {
            id: "vector-problem-02",
            title: "ভেক্টর সমস্যা ০২",
            href: "/vector-problem-02",
            icon: BookOpen,
          },
          {
            id: "vector-problem-03",
            title: "ভেক্টর সমস্যা ০৩",
            href: "/vector-problem-03",
            icon: BookOpen,
          },
          {
            id: "vector-problem-04",
            title: "ভেক্টর সমস্যা ০৪",
            href: "/vector-problem-04",
            icon: BookOpen,
          },
        ],
      },
      {
        id: "ch1-3",
        number: "তৃতীয় অধ্যায়",
        title: "গতিবিদ্যা",
        english: "Dynamics",
        sims: [
          {
            id: "river-boat",
            title: "নদী ও নৌকা সমস্যা",
            href: "/river-boat",
            icon: Waves,
          },
        ],
      },
      {
        id: "ch1-4",
        number: "চতুর্থ অধ্যায়",
        title: "নিউটনীয় বলবিদ্যা",
        english: "Newtonian Mechanics",
        sims: [
          {
            id: "atwood-machine",
            title: "অ্যাটউড মেশিন",
            href: "/atwood-machine",
            icon: Weight,
          },
          {
            id: "atwood-simulator",
            title: "অ্যাটউড সিমুলেটর",
            href: "/atwood-simulator",
            icon: Activity,
          },
          {
            id: "compound-atwood",
            title: "যৌগিক অ্যাটউড মেশিন",
            href: "/compound-atwood",
            icon: Layers,
          },
          {
            id: "three-pulley",
            title: "তিন পুলি সংযোগ",
            href: "/three-pulley",
            icon: GitFork,
          },
        ],
      },
      {
        id: "ch1-5",
        number: "পঞ্চম অধ্যায়",
        title: "কাজ, শক্তি ও ক্ষমতা",
        english: "Work, Energy, and Power",
        sims: [],
      },
      {
        id: "ch1-6",
        number: "ষষ্ঠ অধ্যায়",
        title: "মহাকর্ষ ও অভিকর্ষ",
        english: "Gravitation and Gravity",
        sims: [],
      },
      {
        id: "ch1-7",
        number: "সপ্তম অধ্যায়",
        title: "পদার্থের গাঠনিক ধর্ম",
        english: "Structural Properties of Matter",
        sims: [],
      },
      {
        id: "ch1-8",
        number: "অষ্টম অধ্যায়",
        title: "পর্যাবৃত্ত গতি",
        english: "Periodic Motion",
        sims: [],
      },
      {
        id: "ch1-9",
        number: "নবম অধ্যায়",
        title: "তরঙ্গ",
        english: "Waves",
        sims: [],
      },
      {
        id: "ch1-10",
        number: "দশম অধ্যায়",
        title: "আদর্শ গ্যাস ও গ্যাসের গতিতত্ত্ব",
        english: "Ideal Gas and Kinetic Theory of Gases",
        sims: [{ id: "ideal-gas-sim", title: "আদর্শ গ্যাস সিমুলেটর", href: "/ideal-gas-sim", icon: Activity }],
      },
    ],
  },
  {
    id: "book2",
    title: "পদার্থবিজ্ঞান — ২য় পত্র",
    subtitle: "Physics Second Paper",
    lab: "পদার্থবিজ্ঞান ল্যাব",
    color: "#818cf8",
    glow: "rgba(129,140,248,0.25)",
    icon: Atom,
    chapters: [
      {
        id: "ch2-1",
        number: "প্রথম অধ্যায়",
        title: "তাপগতিবিদ্যা",
        english: "Thermodynamics",
        sims: [],
      },
      {
        id: "ch2-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "স্থির তড়িৎ",
        english: "Static Electricity",
        sims: [],
      },
      {
        id: "ch2-3",
        number: "তৃতীয় অধ্যায়",
        title: "চল তড়িৎ",
        english: "Current Electricity",
        sims: [
          {
            id: "circuit-maker",
            title: "তড়িৎ বর্তনী নির্মাতা",
            href: "/circuit-maker",
            icon: Cpu,
          },
        ],
      },
      {
        id: "ch2-4",
        number: "চতুর্থ অধ্যায়",
        title: "তড়িৎ প্রবাহের চৌম্বক ক্রিয়া ও চুম্বকত্ব",
        english: "Magnetic Effect of Electric Current and Magnetism",
        sims: [],
      },
      {
        id: "ch2-5",
        number: "পঞ্চম অধ্যায়",
        title: "তাড়িতচৌম্বক আবেশ ও পরিবর্তী প্রবাহ",
        english: "Electromagnetic Induction and Alternating Current",
        sims: [],
      },
      {
        id: "ch2-6",
        number: "ষষ্ঠ অধ্যায়",
        title: "জ্যামিতিক আলোকবিজ্ঞান",
        english: "Geometric Optics",
        sims: [],
      },
      {
        id: "ch2-7",
        number: "সপ্তম অধ্যায়",
        title: "ভৌত আলোকবিজ্ঞান",
        english: "Physical Optics",
        sims: [],
      },
      {
        id: "ch2-8",
        number: "অষ্টম অধ্যায়",
        title: "আধুনিক পদার্থবিজ্ঞানের সূচনা",
        english: "Introduction to Modern Physics",
        sims: [
          {
            id: "length-contraction",
            title: "দৈর্ঘ্য সংকোচন",
            href: "/length-contraction",
            icon: Ruler,
          },
          {
            id: "relative-mass",
            title: "আপেক্ষিক ভর",
            href: "/relative-mass",
            icon: Atom,
          },
        ],
      },
      {
        id: "ch2-9",
        number: "নবম অধ্যায়",
        title: "পরমাণুর মডেল এবং নিউক্লিয়ার পদার্থবিজ্ঞান",
        english: "Atomic Model and Nuclear Physics",
        sims: [],
      },
      {
        id: "ch2-10",
        number: "দশম অধ্যায়",
        title: "সেমিকন্ডাক্টর ও ইলেকট্রনিক্স",
        english: "Semiconductors and Electronics",
        sims: [],
      },
      {
        id: "ch2-11",
        number: "একাদশ অধ্যায়",
        title: "জ্যোতির্বিজ্ঞান",
        english: "Astronomy",
        sims: [],
      },
    ],
  },
  {
    id: "chem1",
    title: "রসায়ন — ১ম পত্র",
    subtitle: "Chemistry First Paper",
    lab: "রসায়ন ল্যাব",
    color: "#34d399",
    glow: "rgba(52,211,153,0.25)",
    icon: FlaskRound,
    chapters: [
      {
        id: "chem1-1",
        number: "প্রথম অধ্যায়",
        title: "ল্যাবরেটরির নিরাপদ ব্যবহার",
        english: "Safe Use of Laboratory",
        sims: [],
      },
      {
        id: "chem1-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "গুণগত রসায়ন",
        english: "Qualitative Chemistry",
        sims: [],
      },
      {
        id: "chem1-3",
        number: "তৃতীয় অধ্যায়",
        title: "মৌলের পর্যায়বৃত্ত ধর্ম ও রাসায়নিক বন্ধন",
        english: "Periodic Properties of Elements and Chemical Bonding",
        sims: [{ id: "hybridization-3d", title: "হাইব্রিডাইজেশন ৩D ভিউয়ার", href: "/hybridization-3d", icon: Cpu }],
      },
      {
        id: "chem1-4",
        number: "চতুর্থ অধ্যায়",
        title: "রাসায়নিক পরিবর্তন",
        english: "Chemical Change",
        sims: [],
      },
      {
        id: "chem1-5",
        number: "পঞ্চম অধ্যায়",
        title: "কর্মমুখী রসায়ন",
        english: "Working Chemistry",
        sims: [],
      },
    ],
  },
  {
    id: "chem2",
    title: "রসায়ন — ২য় পত্র",
    subtitle: "Chemistry Second Paper",
    lab: "রসায়ন ল্যাব",
    color: "#2dd4bf",
    glow: "rgba(45,212,191,0.25)",
    icon: FlaskRound,
    chapters: [
      {
        id: "chem2-1",
        number: "প্রথম অধ্যায়",
        title: "পরিবেশ রসায়ন",
        english: "Environmental Chemistry",
        sims: [],
      },
      {
        id: "chem2-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "জৈব রসায়ন",
        english: "Organic Chemistry",
        sims: [{ id: "chain-isomerism", title: "চেইন আইসোমেরিজম বিল্ডার", href: "/chain-isomerism", icon: GitFork }],
      },
      {
        id: "chem2-3",
        number: "তৃতীয় অধ্যায়",
        title: "পরিমাণগত রসায়ন",
        english: "Quantitative Chemistry",
        sims: [{ id: "titration-simulator", title: "টাইট্রেশন সিমুলেটর", href: "/titration-simulator", icon: FlaskConical }],
      },
      {
        id: "chem2-4",
        number: "চতুর্থ অধ্যায়",
        title: "তড়িৎ রসায়ন",
        english: "Electrochemistry",
        sims: [{ id: "galvanic-cell", title: "গ্যালভানিক সেল বিল্ডার", href: "/galvanic-cell", icon: Zap }],
      },
      {
        id: "chem2-5",
        number: "পঞ্চম অধ্যায়",
        title: "অর্থনৈতিক রসায়ন",
        english: "Economic Chemistry",
        sims: [],
      },
    ],
  },
  {
    id: "bio1",
    title: "জীববিজ্ঞান — ১ম পত্র",
    subtitle: "Biology (Botany) First Paper",
    lab: "জীববিজ্ঞান ল্যাব",
    color: "#86efac",
    glow: "rgba(134,239,172,0.25)",
    icon: Leaf,
    chapters: [
      {
        id: "bio1-1",
        number: "প্রথম অধ্যায়",
        title: "কোষ ও এর গঠন",
        english: "Cell and its Structure",
        sims: [],
      },
      {
        id: "bio1-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "কোষ বিভাজন",
        english: "Cell Division",
        sims: [],
      },
      {
        id: "bio1-3",
        number: "তৃতীয় অধ্যায়",
        title: "কোষ রসায়ন",
        english: "Cell Chemistry",
        sims: [],
      },
      {
        id: "bio1-4",
        number: "চতুর্থ অধ্যায়",
        title: "অণুজীব",
        english: "Microorganisms — Virus, Bacteria",
        sims: [],
      },
      {
        id: "bio1-5",
        number: "পঞ্চম অধ্যায়",
        title: "শৈবাল ও ছত্রাক",
        english: "Algae and Fungi",
        sims: [],
      },
      {
        id: "bio1-6",
        number: "ষষ্ঠ অধ্যায়",
        title: "ব্রায়োফাইটা ও টেরিডোফাইটা",
        english: "Bryophyta & Pteridophyta",
        sims: [],
      },
      {
        id: "bio1-7",
        number: "সপ্তম অধ্যায়",
        title: "নগ্নবীজী ও আবৃতবীজী উদ্ভিদ",
        english: "Gymnosperms & Angiosperms",
        sims: [],
      },
      {
        id: "bio1-8",
        number: "অষ্টম অধ্যায়",
        title: "টিস্যু ও টিস্যুতন্ত্র",
        english: "Tissue and Tissue System",
        sims: [],
      },
      {
        id: "bio1-9",
        number: "নবম অধ্যায়",
        title: "উদ্ভিদ শারীরতত্ত্ব",
        english: "Plant Physiology",
        sims: [],
      },
      {
        id: "bio1-10",
        number: "দশম অধ্যায়",
        title: "উদ্ভিদ প্রজনন",
        english: "Plant Reproduction",
        sims: [],
      },
      {
        id: "bio1-11",
        number: "একাদশ অধ্যায়",
        title: "জীবপ্রযুক্তি",
        english: "Biotechnology",
        sims: [],
      },
      {
        id: "bio1-12",
        number: "দ্বাদশ অধ্যায়",
        title: "জীবের পরিবেশ, বিস্তার ও সংরক্ষণ",
        english: "Environment, Distribution and Conservation",
        sims: [],
      },
    ],
  },
  {
    id: "bio2",
    title: "জীববিজ্ঞান — ২য় পত্র",
    subtitle: "Biology (Zoology) Second Paper",
    lab: "জীববিজ্ঞান ল্যাব",
    color: "#f9a8d4",
    glow: "rgba(249,168,212,0.25)",
    icon: Leaf,
    chapters: [
      {
        id: "bio2-1",
        number: "প্রথম অধ্যায়",
        title: "প্রাণীর বিভিন্নতা ও শ্রেণিবিন্যাস",
        english: "Animal Diversity and Classification",
        sims: [],
      },
      {
        id: "bio2-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "প্রাণীর পরিচিতি",
        english: "Introduction to Animals — হাইড্রা, ঘাসফড়িং, রুই মাছ",
        sims: [],
      },
      {
        id: "bio2-3",
        number: "তৃতীয় অধ্যায়",
        title: "মানব শারীরতত্ত্ব: পরিপাক ও শোষণ",
        english: "Digestion and Absorption",
        sims: [],
      },
      {
        id: "bio2-4",
        number: "চতুর্থ অধ্যায়",
        title: "মানব শারীরতত্ত্ব: রক্ত ও সঞ্চালন",
        english: "Blood and Circulation",
        sims: [],
      },
      {
        id: "bio2-5",
        number: "পঞ্চম অধ্যায়",
        title: "মানব শারীরতত্ত্ব: শ্বাসক্রিয়া ও শ্বসন",
        english: "Breathing and Respiration",
        sims: [],
      },
      {
        id: "bio2-6",
        number: "ষষ্ঠ অধ্যায়",
        title: "মানব শারীরতত্ত্ব: বর্জ্য ও নিষ্কাশন",
        english: "Excretion and Elimination",
        sims: [],
      },
      {
        id: "bio2-7",
        number: "সপ্তম অধ্যায়",
        title: "মানব শারীরতত্ত্ব: চলন ও অঙ্গচালনা",
        english: "Locomotion and Movement",
        sims: [],
      },
      {
        id: "bio2-8",
        number: "অষ্টম অধ্যায়",
        title: "মানব শারীরতত্ত্ব: সমন্বয় ও নিয়ন্ত্রণ",
        english: "Coordination and Control",
        sims: [],
      },
      {
        id: "bio2-9",
        number: "নবম অধ্যায়",
        title: "মানব জীবনের ধারাবাহিকতা",
        english: "Reproduction / Continuity of Human Life",
        sims: [],
      },
      {
        id: "bio2-10",
        number: "দশম অধ্যায়",
        title: "মানবদেহের প্রতিরক্ষা",
        english: "Human Body Defense / Immunity",
        sims: [],
      },
      {
        id: "bio2-11",
        number: "একাদশ অধ্যায়",
        title: "জিনতত্ত্ব ও বিবর্তন",
        english: "Genetics and Evolution",
        sims: [{ id: "punnett-square", title: "পানেট স্কোয়ার — জেনেটিক বিল্ডার", href: "/punnett-square", icon: Layers }],
      },
      {
        id: "bio2-12",
        number: "দ্বাদশ অধ্যায়",
        title: "প্রাণীর আচরণ",
        english: "Animal Behavior",
        sims: [],
      },
    ],
  },
  {
    id: "math1",
    title: "উচ্চতর গণিত — ১ম পত্র",
    subtitle: "Higher Mathematics First Paper",
    lab: "গণিত ল্যাব",
    color: "#c4b5fd",
    glow: "rgba(196,181,253,0.25)",
    icon: Calculator,
    chapters: [
      {
        id: "math1-1",
        number: "প্রথম অধ্যায়",
        title: "ম্যাট্রিক্স ও নির্ণায়ক",
        english: "Matrix and Determinants",
        sims: [],
      },
      {
        id: "math1-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "ভেক্টর",
        english: "Vectors",
        sims: [],
      },
      {
        id: "math1-3",
        number: "তৃতীয় অধ্যায়",
        title: "সরলরেখা",
        english: "Straight Lines",
        sims: [],
      },
      {
        id: "math1-4",
        number: "চতুর্থ অধ্যায়",
        title: "বৃত্ত",
        english: "Circle",
        sims: [],
      },
      {
        id: "math1-5",
        number: "পঞ্চম অধ্যায়",
        title: "বিন্যাস ও সমাবেশ",
        english: "Permutation and Combination",
        sims: [],
      },
      {
        id: "math1-6",
        number: "ষষ্ঠ অধ্যায়",
        title: "ত্রিকোণমিতিক অনুপাত",
        english: "Trigonometric Ratios",
        sims: [{ id: "trig-unit-circle", title: "ট্রিগ ইউনিট সার্কেল ক্লক", href: "/trig-unit-circle", icon: Ruler }],
      },
      {
        id: "math1-7",
        number: "সপ্তম অধ্যায়",
        title: "সংযুক্ত কোণের ত্রিকোণমিতিক অনুপাত",
        english: "Trigonometric Ratios of Associated Angles",
        sims: [],
      },
      {
        id: "math1-8",
        number: "অষ্টম অধ্যায়",
        title: "ফাংশন ও ফাংশনের লেখচিত্র",
        english: "Functions and Graphs",
        sims: [],
      },
      {
        id: "math1-9",
        number: "নবম অধ্যায়",
        title: "অন্তরীকরণ",
        english: "Differentiation",
        sims: [],
      },
      {
        id: "math1-10",
        number: "দশম অধ্যায়",
        title: "যোগজীকরণ",
        english: "Integration",
        sims: [],
      },
    ],
  },
  {
    id: "math2",
    title: "উচ্চতর গণিত — ২য় পত্র",
    subtitle: "Higher Mathematics Second Paper",
    lab: "গণিত ল্যাব",
    color: "#a78bfa",
    glow: "rgba(167,139,250,0.25)",
    icon: Calculator,
    chapters: [
      {
        id: "math2-1",
        number: "প্রথম অধ্যায়",
        title: "বাস্তব সংখ্যা ও অসমতা",
        english: "Real Numbers and Inequalities",
        sims: [],
      },
      {
        id: "math2-2",
        number: "দ্বিতীয় অধ্যায়",
        title: "যোগাশ্রয়ী প্রোগ্রাম",
        english: "Linear Programming",
        sims: [],
      },
      {
        id: "math2-3",
        number: "তৃতীয় অধ্যায়",
        title: "জটিল সংখ্যা",
        english: "Complex Numbers",
        sims: [],
      },
      {
        id: "math2-4",
        number: "চতুর্থ অধ্যায়",
        title: "বহুপদী ও বহুপদী সমীকরণ",
        english: "Polynomials and Polynomial Equations",
        sims: [],
      },
      {
        id: "math2-5",
        number: "পঞ্চম অধ্যায়",
        title: "দ্বিপদী বিস্তৃতি",
        english: "Binomial Expansion",
        sims: [],
      },
      {
        id: "math2-6",
        number: "ষষ্ঠ অধ্যায়",
        title: "কণিক",
        english: "Conics — Parabola, Ellipse, Hyperbola",
        sims: [],
      },
      {
        id: "math2-7",
        number: "সপ্তম অধ্যায়",
        title: "বিপরীত ত্রিকোণমিতিক ফাংশন ও সমীকরণ",
        english: "Inverse Trigonometric Functions",
        sims: [],
      },
      {
        id: "math2-8",
        number: "অষ্টম অধ্যায়",
        title: "স্থিতিবিদ্যা",
        english: "Statics",
        sims: [],
      },
      {
        id: "math2-9",
        number: "নবম অধ্যায়",
        title: "গতিবিদ্যা",
        english: "Dynamics",
        sims: [],
      },
      {
        id: "math2-10",
        number: "দশম অধ্যায়",
        title: "বিস্তার পরিমাপ ও সম্ভাবনা",
        english: "Measures of Dispersion and Probability",
        sims: [],
      },
    ],
  },
];

function PhysicsBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let animId: number;
    const mousePos = { x: -9999, y: -9999 };

    function resize() {
      canvas!.width = window.innerWidth;
      canvas!.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    const COLORS = ["#f59e42", "#ef4444", "#818cf8", "#34d399", "#f472b6"];

    const particles = Array.from({ length: 80 }, () => {
      const angle = Math.random() * Math.PI * 2;
      const dist = 50 + Math.random() * 300;
      return {
        x: canvas!.width / 2 + Math.cos(angle) * dist,
        y: canvas!.height / 2 + Math.sin(angle) * dist,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        ax: 0,
        ay: 0,
        radius: Math.random() * 2.5 + 0.8,
        trail: [] as { x: number; y: number }[],
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
      };
    });

    function onMouseMove(e: MouseEvent) {
      mousePos.x = e.clientX;
      mousePos.y = e.clientY;
    }
    document.addEventListener("mousemove", onMouseMove);

    function distFn(x1: number, y1: number, x2: number, y2: number) {
      return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    }

    function animate() {
      ctx.clearRect(0, 0, canvas!.width, canvas!.height);
      const cx = canvas!.width / 2;
      const cy = canvas!.height / 2;

      particles.forEach((p) => {
        const d = distFn(p.x, p.y, cx, cy);
        if (d > 10) {
          const a = Math.atan2(cy - p.y, cx - p.x);
          p.ax = Math.cos(a) * 0.0008;
          p.ay = Math.sin(a) * 0.0008;
        }
        const md = distFn(p.x, p.y, mousePos.x, mousePos.y);
        if (md < 150 && md > 0) {
          const a = Math.atan2(p.y - mousePos.y, p.x - mousePos.x);
          p.ax += Math.cos(a) * 0.003;
          p.ay += Math.sin(a) * 0.003;
        }
        p.vx = (p.vx + p.ax) * 0.99;
        p.vy = (p.vy + p.ay) * 0.99;
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < p.radius) {
          p.x = p.radius;
          p.vx *= -0.5;
        }
        if (p.x > canvas!.width - p.radius) {
          p.x = canvas!.width - p.radius;
          p.vx *= -0.5;
        }
        if (p.y < p.radius) {
          p.y = p.radius;
          p.vy *= -0.5;
        }
        if (p.y > canvas!.height - p.radius) {
          p.y = canvas!.height - p.radius;
          p.vy *= -0.5;
        }

        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > 50) p.trail.shift();

        if (p.trail.length > 1) {
          ctx.strokeStyle = p.color + "22";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(p.trail[0].x, p.trail[0].y);
          for (let i = 1; i < p.trail.length; i++)
            ctx.lineTo(p.trail[i].x, p.trail[i].y);
          ctx.stroke();
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color + "cc";
        ctx.shadowBlur = 15;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const d = distFn(
            particles[i].x,
            particles[i].y,
            particles[j].x,
            particles[j].y,
          );
          if (d < 150) {
            const alpha = Math.floor((1 - d / 150) * 40)
              .toString(16)
              .padStart(2, "0");
            ctx.strokeStyle = particles[i].color + alpha;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      animId = requestAnimationFrame(animate);
    }
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
      document.removeEventListener("mousemove", onMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 0,
        pointerEvents: "none",
      }}
    />
  );
}

function SimCard({ sim, color }: { sim: Sim; color: string }) {
  return (
    <Link href={sim.href} className="block outline-none group">
      <motion.div
        whileHover={{ x: 4 }}
        className="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-150"
        style={{
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLDivElement).style.background = `${color}18`;
          (e.currentTarget as HTMLDivElement).style.borderColor = `${color}50`;
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLDivElement).style.background =
            "rgba(255,255,255,0.04)";
          (e.currentTarget as HTMLDivElement).style.borderColor =
            "rgba(255,255,255,0.08)";
        }}
      >
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ background: `${color}22`, color }}
        >
          <sim.icon size={14} strokeWidth={2.5} />
        </div>
        <span
          className="text-sm font-semibold"
          style={{ color: "rgba(245,245,245,0.9)" }}
        >
          {sim.title}
        </span>
        <ChevronRight
          size={14}
          className="ml-auto flex-shrink-0 opacity-0 group-hover:opacity-60 transition-opacity"
          style={{ color }}
        />
      </motion.div>
    </Link>
  );
}

function ChapterRow({
  chapter,
  color,
  defaultOpen,
}: {
  chapter: Chapter;
  color: string;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen ?? false);
  const hasSims = chapter.sims.length > 0;

  return (
    <div>
      <button
        onClick={() => hasSims && setOpen((o) => !o)}
        className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-150 outline-none"
        style={{
          cursor: hasSims ? "pointer" : "default",
          opacity: hasSims ? 1 : 0.5,
        }}
        onMouseEnter={(e) => {
          if (hasSims)
            (e.currentTarget as HTMLButtonElement).style.background =
              "rgba(255,255,255,0.05)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLButtonElement).style.background =
            "transparent";
        }}
      >
        <div
          className="flex-shrink-0 w-1.5 h-1.5 rounded-full mt-0.5"
          style={{ background: hasSims ? color : "rgba(255,255,255,0.2)" }}
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 flex-wrap">
            <span
              className="text-xs font-mono"
              style={{ color: hasSims ? color : "rgba(255,255,255,0.3)" }}
            >
              {chapter.number}
            </span>
            <span
              className="text-sm font-bold"
              style={{
                color: hasSims
                  ? "rgba(245,245,245,0.95)"
                  : "rgba(255,255,255,0.4)",
              }}
            >
              {chapter.title}
            </span>
          </div>
          <div
            className="text-xs mt-0.5"
            style={{ color: "rgba(255,255,255,0.25)" }}
          >
            {chapter.english}
          </div>
        </div>
        {hasSims && (
          <div className="flex items-center gap-2 flex-shrink-0">
            <span
              className="text-xs font-mono px-1.5 py-0.5 rounded-md"
              style={{ background: `${color}22`, color }}
            >
              {chapter.sims.length}
            </span>
            <ChevronDown
              size={15}
              style={{
                color: "rgba(255,255,255,0.4)",
                transform: open ? "rotate(180deg)" : "rotate(0deg)",
                transition: "transform 0.2s",
              }}
            />
          </div>
        )}
      </button>

      <AnimatePresence initial={false}>
        {open && hasSims && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22, ease: "easeInOut" }}
            style={{ overflow: "hidden" }}
          >
            <div
              className="ml-4 pl-4 pb-2 flex flex-col gap-1"
              style={{ borderLeft: `1.5px solid ${color}30` }}
            >
              {chapter.sims.map((sim) => (
                <SimCard key={sim.id} sim={sim} color={color} />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function BookPanel({
  book,
  isOpen,
  onToggle,
}: {
  book: Book;
  isOpen: boolean;
  onToggle: () => void;
}) {
  const totalSims = book.chapters.reduce((acc, ch) => acc + ch.sims.length, 0);
  const chaptersWithSims = book.chapters.filter(
    (ch) => ch.sims.length > 0,
  ).length;

  return (
    <div className="flex flex-col" style={{ minWidth: 0 }}>
      <motion.button
        onClick={onToggle}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        className="w-full rounded-2xl p-6 text-left outline-none transition-all duration-200 relative overflow-hidden"
        style={{
          background: isOpen
            ? `linear-gradient(135deg, ${book.color}22, ${book.color}10)`
            : "rgba(255,255,255,0.05)",
          border: `2px solid ${isOpen ? book.color + "60" : "rgba(255,255,255,0.1)"}`,
          boxShadow: isOpen ? `0 0 40px ${book.glow}` : "none",
        }}
      >
        <div className="flex items-center gap-4">
          <div
            className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: `${book.color}22`,
              border: `1.5px solid ${book.color}40`,
            }}
          >
            <book.icon
              size={26}
              style={{ color: book.color }}
              strokeWidth={2}
            />
          </div>
          <div className="flex-1 min-w-0">
            <div
              className="text-xs font-semibold mb-1 px-2 py-0.5 rounded-full inline-block"
              style={{ background: `${book.color}25`, color: book.color, letterSpacing: "0.05em" }}
            >
              {book.lab}
            </div>
            <div
              className="text-xl md:text-2xl font-extrabold leading-tight"
              style={{ color: "#f5f5f5" }}
            >
              {book.title}
            </div>
            <div
              className="text-sm mt-1 font-medium"
              style={{ color: "rgba(245,245,245,0.5)" }}
            >
              {book.subtitle}
            </div>
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              <span
                className="text-xs font-mono px-2 py-0.5 rounded-full"
                style={{ background: `${book.color}22`, color: book.color }}
              >
                {book.chapters.length} অধ্যায়
              </span>
              <span
                className="text-xs font-mono px-2 py-0.5 rounded-full"
                style={{ background: `${book.color}22`, color: book.color }}
              >
                {totalSims} সিমুলেশন
              </span>
              <span
                className="text-xs font-mono"
                style={{ color: "rgba(255,255,255,0.3)" }}
              >
                {chaptersWithSims} অধ্যায়ে সিমুলেশন আছে
              </span>
            </div>
          </div>
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.25 }}
            className="flex-shrink-0"
          >
            <ChevronDown
              size={24}
              style={{ color: isOpen ? book.color : "rgba(255,255,255,0.4)" }}
            />
          </motion.div>
        </div>
      </motion.button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            style={{ overflow: "hidden" }}
          >
            <div
              className="mt-2 rounded-2xl p-4 flex flex-col gap-1"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: `1.5px solid ${book.color}20`,
              }}
            >
              {book.chapters.map((chapter, idx) => (
                <ChapterRow
                  key={chapter.id}
                  chapter={chapter}
                  color={book.color}
                  defaultOpen={idx === 0 && chapter.sims.length > 0}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function Home() {
  const [openBook, setOpenBook] = useState<string | null>(null);

  const toggle = (id: string) =>
    setOpenBook((prev) => (prev === id ? null : id));

  return (
    <div
      style={{ background: "#0a0e1a", minHeight: "100vh", color: "#f5f5f5" }}
    >
      <PhysicsBackground />
      <div
        style={{
          position: "relative",
          zIndex: 10,
          display: "flex",
          flexDirection: "column",
          minHeight: "100vh",
        }}
      >
        <nav
          style={{
            position: "sticky",
            top: 0,
            zIndex: 50,
            borderBottom: "1px solid rgba(255,255,255,0.1)",
            background: "rgba(10,14,26,0.85)",
            backdropFilter: "blur(12px)",
          }}
        >
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="বিজ্ঞান ল্যাব" className="w-16 h-16 object-contain" />
              <span className="font-bold text-lg tracking-tight text-white">
                বিজ্ঞান ল্যাব
              </span>
            </div>
            <span
              className="text-sm italic"
              style={{ color: "rgba(255,255,255,0.35)" }}
            >
              created by Mahe
            </span>
          </div>
        </nav>

        <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
          <div className="max-w-2xl mx-auto text-center mb-10 pt-4">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-4xl md:text-5xl font-extrabold tracking-tight mb-3"
              style={{ color: "#f5f5f5" }}
            >
              এইচ.এস.সি বিজ্ঞান
              <br />
              <span style={{ color: "#f59e42" }}>ল্যাব</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.35 }}
              className="text-base md:text-lg"
              style={{ color: "rgba(245,245,245,0.55)" }}
            >
              অধ্যায় বেছে নিন, সিমুলেশন দেখুন এবং বিজ্ঞানকে অনুভব করুন!
            </motion.p>
          </div>

          <div className="flex flex-col gap-4">
            {BOOKS.map((book, idx) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + idx * 0.1 }}
              >
                <BookPanel
                  book={book}
                  isOpen={openBook === book.id}
                  onToggle={() => toggle(book.id)}
                />
              </motion.div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
