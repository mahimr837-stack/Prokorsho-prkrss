import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Card, Panel, LabeledSlider, MathFormula, setupHighDPICanvas, drawGrid, drawVector } from "@/components/ui-elements";
import { motion } from "framer-motion";

export function VectorComponents() {
  const [mag, setMag] = useState(150);
  const [ang, setAng] = useState(45);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  const rad = (ang * Math.PI) / 180;
  const vx = mag * Math.cos(rad);
  const vy = mag * Math.sin(rad);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvasObj = setupHighDPICanvas(canvasRef.current);
    if (!canvasObj) return;
    
    const { ctx, width, height } = canvasObj;
    const ox = width / 2;
    const oy = height / 2;

    ctx.clearRect(0, 0, width, height);
    drawGrid(ctx, width, height);

    const map = (x: number, y: number) => [ox + x, oy - y];
    const [vxc, vyc] = map(vx, vy);
    const [vx_endX, vx_endY] = map(vx, 0);
    const [vy_endX, vy_endY] = map(0, vy);

    // Draw Dashed Rectangle
    ctx.beginPath();
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = "#94a3b8"; // slate-400
    ctx.lineWidth = 1.5;
    ctx.moveTo(vx_endX, vx_endY);
    ctx.lineTo(vxc, vyc);
    ctx.lineTo(vy_endX, vy_endY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw Vector Components
    drawVector(ctx, ox, oy, vx_endX, vx_endY, "#ef4444", "Vx"); // X component Red
    drawVector(ctx, ox, oy, vy_endX, vy_endY, "#14b8a6", "Vy"); // Y component Teal
    
    // Draw Main Vector
    drawVector(ctx, ox, oy, vxc, vyc, "#09090b", "V"); // Main vector Dark

    // Draw Angle Arc
    if (mag > 20) {
      ctx.beginPath();
      ctx.arc(ox, oy, 30, ang > 180 ? 0 : -rad, ang > 180 ? -rad : 0, ang <= 180);
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 2;
      ctx.stroke();
    }

  }, [mag, ang, vx, vy]);

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold mb-2">Vector Components</h1>
        <p className="text-muted-foreground">Decompose a vector into its orthogonal Cartesian components.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="p-1 h-[500px] flex items-center justify-center bg-zinc-50/50">
            <canvas ref={canvasRef} className="w-full h-full rounded-xl" />
          </Card>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="h-full">
            <Panel title="Configuration">
              <div className="space-y-8 mb-8">
                <LabeledSlider label="Magnitude (V)" value={mag} min={20} max={250} onChange={setMag} />
                <LabeledSlider label="Angle (θ)" value={ang} min={0} max={360} unit="°" onChange={setAng} />
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Calculations</h4>
                
                <MathFormula className="border-l-4 border-l-[#ef4444]">
                  <span className="text-muted-foreground">V_x = V · cos(θ)</span>
                  <span className="text-foreground">{vx.toFixed(2)}</span>
                </MathFormula>
                
                <MathFormula className="border-l-4 border-l-[#14b8a6]">
                  <span className="text-muted-foreground">V_y = V · sin(θ)</span>
                  <span className="text-foreground">{vy.toFixed(2)}</span>
                </MathFormula>

                <div className="pt-4 mt-4 border-t">
                  <MathFormula>
                    <span className="text-muted-foreground">|V| = √(Vx² + Vy²)</span>
                    <span className="text-foreground">{Math.sqrt(vx*vx + vy*vy).toFixed(2)}</span>
                  </MathFormula>
                </div>
              </div>
            </Panel>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
