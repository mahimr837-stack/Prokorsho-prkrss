import { Layout } from "@/components/layout";

export function RelativeMass() {
  return (
    <Layout>
      <div className="-mx-4 sm:-mx-6 lg:-mx-8 -my-8 lg:-my-12" style={{ height: "calc(100vh - 64px)" }}>
        <iframe
          src="/sims/relative-mass.html"
          className="w-full h-full border-0"
          title="আপেক্ষিক ভর — বিশেষ আপেক্ষিকতা"
        />
      </div>
    </Layout>
  );
}
