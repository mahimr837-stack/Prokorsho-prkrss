import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Card, Panel, LabeledSlider, MathFormula, setupHighDPICanvas, drawGrid, drawVector } from "@/components/ui-elements";
import { motion } from "framer-motion";

export function VectorAddition() {
  const [pMag, setPMag] = useState(100);
  const [pAng, setPAng] = useState(30);
  const [qMag, setQMag] = useState(80);
  const [qAng, setQAng] = useState(120);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Derived calculations
  const pRad = (pAng * Math.PI) / 180;
  const qRad = (qAng * Math.PI) / 180;
  
  const px = pMag * Math.cos(pRad);
  const py = pMag * Math.sin(pRad);
  
  const qx = qMag * Math.cos(qRad);
  const qy = qMag * Math.sin(qRad);
  
  const rx = px + qx;
  const ry = py + qy;
  
  const rMag = Math.sqrt(rx * rx + ry * ry);
  let rAng = (Math.atan2(ry, rx) * 180) / Math.PI;
  if (rAng < 0) rAng += 360;

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvasObj = setupHighDPICanvas(canvasRef.current);
    if (!canvasObj) return;
    
    const { ctx, width, height } = canvasObj;
    const ox = width / 2;
    const oy = height / 2; // Y goes down in canvas, but up in math

    ctx.clearRect(0, 0, width, height);
    drawGrid(ctx, width, height);

    // Helper to map math coords to canvas coords
    const map = (x: number, y: number) => [ox + x, oy - y];

    const [pxc, pyc] = map(px, py);
    const [qxc, qyc] = map(qx, qy);
    const [rxc, ryc] = map(rx, ry);

    // Vector P (Red)
    drawVector(ctx, ox, oy, pxc, pyc, "#ef4444", "P");
    
    // Vector Q from origin (Parallelogram law) - Teal
    drawVector(ctx, ox, oy, qxc, qyc, "#14b8a6", "Q");
    
    // Vector Q from P head (Triangle law)
    drawVector(ctx, pxc, pyc, rxc, ryc, "#14b8a6", "Q'", true);
    
    // Vector P from Q head (Parallelogram completion)
    drawVector(ctx, qxc, qyc, rxc, ryc, "#ef4444", "P'", true);

    // Resultant R (Gold)
    drawVector(ctx, ox, oy, rxc, ryc, "#f59e0b", "R");

  }, [pMag, pAng, qMag, qAng, px, py, qx, qy, rx, ry]);

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold mb-2">Vector Addition</h1>
        <p className="text-muted-foreground">Visualize Triangle and Parallelogram laws of vector addition.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card className="p-1 h-[500px] flex items-center justify-center bg-zinc-50/50">
            <canvas 
              ref={canvasRef} 
              className="w-full h-full rounded-xl"
            />
          </Card>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MathFormula className="border-l-4 border-l-[#ef4444]">
              <span>Vector P</span>
              <span>[{px.toFixed(1)}, {py.toFixed(1)}]</span>
            </MathFormula>
            <MathFormula className="border-l-4 border-l-[#14b8a6]">
              <span>Vector Q</span>
              <span>[{qx.toFixed(1)}, {qy.toFixed(1)}]</span>
            </MathFormula>
          </div>
        </div>

        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <Card className="h-full">
            <Panel title="Vector Controls">
              <div className="space-y-8">
                <div className="p-4 rounded-xl bg-red-50/50 border border-red-100">
                  <h4 className="text-red-600 font-bold mb-4 flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500" /> Vector P
                  </h4>
                  <div className="space-y-6">
                    <LabeledSlider label="Magnitude" value={pMag} min={10} max={250} onChange={setPMag} />
                    <LabeledSlider label="Angle" value={pAng} min={0} max={360} unit="°" onChange={setPAng} />
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-teal-50/50 border border-teal-100">
                  <h4 className="text-teal-600 font-bold mb-4 flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-teal-500" /> Vector Q
                  </h4>
                  <div className="space-y-6">
                    <LabeledSlider label="Magnitude" value={qMag} min={10} max={250} onChange={setQMag} />
                    <LabeledSlider label="Angle" value={qAng} min={0} max={360} unit="°" onChange={setQAng} />
                  </div>
                </div>

                <div className="mt-8 p-5 bg-amber-50/50 border border-amber-200 rounded-xl">
                  <h4 className="text-amber-700 font-bold mb-3 flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-amber-500" /> Resultant R
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-amber-700/70 font-semibold mb-1">MAGNITUDE</div>
                      <div className="text-2xl font-mono text-amber-900">{rMag.toFixed(1)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-amber-700/70 font-semibold mb-1">ANGLE</div>
                      <div className="text-2xl font-mono text-amber-900">{rAng.toFixed(1)}°</div>
                    </div>
                  </div>
                </div>
              </div>
            </Panel>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
