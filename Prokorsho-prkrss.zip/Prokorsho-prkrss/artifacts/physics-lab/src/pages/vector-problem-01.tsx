import { useEffect, useRef, useState } from "react";
import { Layout } from "@/components/layout";

const problem = "দুইটি ভেক্টরের মধ্যে একটি অন্যটির দ্বিগুণ এবং এদের লব্ধির মান বড় ভেক্টরের সমান হলে, ভেক্টরদ্বয়ের মধ্যকার কোণের মান কত?";
const steps = [
  "ধরি, ছোট ভেক্টরের মান = A",
  "তাহলে, বড় ভেক্টরের মান = 2A",
  "লব্ধি R = 2A (দেওয়া আছে)",
  "ভেক্টর সংযোজনের সূত্র: R² = A² + B² + 2AB cos(θ)",
  "(2A)² = A² + (2A)² + 2(A)(2A)cos(θ)",
  "4A² = A² + 4A² + 4A² cos(θ)",
  "4A² = 5A² + 4A² cos(θ)",
  "4A² - 5A² = 4A² cos(θ)",
  "-A² = 4A² cos(θ)",
  "cos(θ) = -A²/4A² = -1/4",
  "θ = cos⁻¹(-1/4)",
  "θ ≈ 104.48° অথবা 104°29'",
];
const answer = "θ ≈ 104.48°";

function typeText(setText: (t: string) => void, text: string, speed = 30): Promise<void> {
  return new Promise((resolve) => {
    let i = 0;
    setText("");
    const interval = setInterval(() => {
      if (i < text.length) { setText(text.slice(0, ++i)); }
      else { clearInterval(interval); resolve(); }
    }, speed);
  });
}

export function VectorProblem01() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [problemText, setProblemText] = useState("");
  const [solvedSteps, setSolvedSteps] = useState<string[]>([]);
  const [answerText, setAnswerText] = useState("");
  const [running, setRunning] = useState(false);

  function drawDiagram() {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    const w = canvas.width, h = canvas.height, cx = w / 2, cy = h / 2;
    ctx.fillStyle = "#faf8f3"; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#e8dcc8"; ctx.lineWidth = 1;
    for (let i = 0; i < w; i += 30) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke(); }
    for (let i = 0; i < h; i += 30) { ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke(); }
    ctx.strokeStyle = "#8b7355"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(cx, 20); ctx.lineTo(cx, h - 20); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(20, cy); ctx.lineTo(w - 20, cy); ctx.stroke();
    ctx.fillStyle = "#8b7355"; ctx.beginPath(); ctx.arc(cx, cy, 5, 0, Math.PI * 2); ctx.fill();
    const scale = 50;
    function drawVec(ex: number, ey: number, color: string, label: string) {
      ctx.strokeStyle = color; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(ex, ey); ctx.stroke();
      const a = Math.atan2(ey - cy, ex - cx);
      ctx.beginPath(); ctx.moveTo(ex, ey);
      ctx.lineTo(ex - 10 * Math.cos(a - Math.PI/6), ey - 10 * Math.sin(a - Math.PI/6));
      ctx.lineTo(ex - 10 * Math.cos(a + Math.PI/6), ey - 10 * Math.sin(a + Math.PI/6));
      ctx.closePath(); ctx.fillStyle = color; ctx.fill();
      ctx.fillStyle = color; ctx.font = "bold 14px sans-serif"; ctx.fillText(label, ex + 8, ey - 8);
    }
    drawVec(cx + scale, cy, "#3498db", "A");
    const ang2 = 104.48 * Math.PI / 180;
    drawVec(cx + scale * 2 * Math.cos(ang2), cy - scale * 2 * Math.sin(ang2), "#27ae60", "2A");
    ctx.strokeStyle = "#8b7355"; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, 30, 0, -ang2, true); ctx.stroke();
    ctx.setLineDash([]); ctx.fillStyle = "#8b7355"; ctx.font = "12px sans-serif"; ctx.fillText("θ≈104°", cx + 35, cy - 10);
  }

  async function start() {
    if (running) return;
    setRunning(true);
    setSolvedSteps([]); setAnswerText("");
    await typeText(setProblemText, problem, 30);
    const collected: string[] = [];
    for (let i = 0; i < steps.length; i++) {
      await new Promise<void>((resolve) => {
        let s = "";
        const interval = setInterval(() => {
          s += steps[i][s.length];
          collected[i] = s;
          setSolvedSteps([...collected]);
          if (s.length === steps[i].length) { clearInterval(interval); resolve(); }
        }, 22);
      });
    }
    await typeText(setAnswerText, answer, 40);
    setRunning(false);
  }

  function reset() { setRunning(false); setProblemText(""); setSolvedSteps([]); setAnswerText(""); }

  useEffect(() => { drawDiagram(); }, []);
  useEffect(() => { start(); }, []);

  return (
    <Layout>
      <div className="mb-6"><h1 className="text-2xl font-bold">ভেক্টর সমস্যা সমাধান</h1></div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="flex flex-col gap-4">
          <div className="bg-card border border-border rounded-xl p-5 border-l-4 border-l-amber-700">
            <h2 className="text-xs font-semibold uppercase tracking-widest text-amber-700 mb-3">প্রশ্ন</h2>
            <p className="text-base leading-relaxed text-foreground min-h-[60px]">{problemText}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-5 border-l-4 border-l-amber-500">
            <h2 className="text-xs font-semibold uppercase tracking-widest text-amber-700 mb-3">সমাধান</h2>
            <div className="flex flex-col gap-3">
              {solvedSteps.map((s, i) => (
                <div key={i} className="bg-muted/50 rounded-lg px-4 py-3 text-sm border-l-2 border-amber-300">
                  <span className="font-semibold text-amber-700 mr-2">ধাপ {i + 1}:</span>{s}
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">রেফারেন্স ডায়াগ্রাম</h3>
            <canvas ref={canvasRef} width={350} height={280} className="w-full rounded-lg" />
          </div>
          <div className="rounded-xl p-5 text-center text-white" style={{background:"linear-gradient(135deg,#d4af9f,#b8956a)"}}>
            <h3 className="text-xs font-semibold uppercase tracking-widest mb-2">চূড়ান্ত উত্তর</h3>
            <div className="text-3xl font-light tracking-widest min-h-[40px]">{answerText}</div>
          </div>
          <button onClick={() => { reset(); setTimeout(start, 100); }}
            className="mx-auto px-8 py-3 rounded-full text-sm font-medium text-white transition-all hover:-translate-y-0.5"
            style={{background:"linear-gradient(135deg,#8b7355,#a0937d)"}}>
            🔄 রিসেট করুন
          </button>
        </div>
      </div>
    </Layout>
  );
}
