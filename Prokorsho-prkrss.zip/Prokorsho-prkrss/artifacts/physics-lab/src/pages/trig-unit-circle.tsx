import { Layout } from "@/components/layout";

export function TrigUnitCircle() {
  return (
    <Layout>
      <div className="-mx-4 sm:-mx-6 lg:-mx-8 -my-8 lg:-my-12" style={{ height: "calc(100vh - 64px)" }}>
        <iframe
          src="/sims/trig-unit-circle.html"
          className="w-full h-full border-0"
          title="Trig Unit Circle Clock"
        />
      </div>
    </Layout>
  );
}
