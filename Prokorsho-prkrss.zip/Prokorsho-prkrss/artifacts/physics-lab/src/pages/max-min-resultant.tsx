import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Card, Panel, LabeledSlider, MathFormula, setupHighDPICanvas, drawGrid, drawVector } from "@/components/ui-elements";
import { motion } from "framer-motion";

export function MaxMinResultant() {
  const [pMag, setPMag] = useState(120);
  const [qMag, setQMag] = useState(80);

  const canvasMaxRef = useRef<HTMLCanvasElement>(null);
  const canvasMinRef = useRef<HTMLCanvasElement>(null);

  // Maximum Case (Same direction, angle = 0)
  useEffect(() => {
    if (!canvasMaxRef.current) return;
    const canvasObj = setupHighDPICanvas(canvasMaxRef.current);
    if (!canvasObj) return;
    
    const { ctx, width, height } = canvasObj;
    ctx.clearRect(0, 0, width, height);
    drawGrid(ctx, width, height, 40);

    const startX = 60;
    const startY = height / 2;

    // Draw P
    drawVector(ctx, startX, startY - 10, startX + pMag, startY - 10, "#ef4444", "P");
    // Draw Q starting from P
    drawVector(ctx, startX + pMag, startY - 10, startX + pMag + qMag, startY - 10, "#14b8a6", "Q");
    // Draw Resultant R below them
    drawVector(ctx, startX, startY + 20, startX + pMag + qMag, startY + 20, "#f59e0b", "R_max");

  }, [pMag, qMag]);

  // Minimum Case (Opposite direction, angle = 180)
  useEffect(() => {
    if (!canvasMinRef.current) return;
    const canvasObj = setupHighDPICanvas(canvasMinRef.current);
    if (!canvasObj) return;
    
    const { ctx, width, height } = canvasObj;
    ctx.clearRect(0, 0, width, height);
    drawGrid(ctx, width, height, 40);

    const startX = 150; // shift right to allow leftward arrows
    const startY = height / 2;

    // Draw P to the right
    drawVector(ctx, startX, startY - 10, startX + pMag, startY - 10, "#ef4444", "P");
    // Draw Q to the left from P's head
    drawVector(ctx, startX + pMag, startY - 10, startX + pMag - qMag, startY - 10, "#14b8a6", "Q");
    // Draw Resultant R below
    drawVector(ctx, startX, startY + 20, startX + (pMag - qMag), startY + 20, "#f59e0b", "R_min");

  }, [pMag, qMag]);

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold mb-2">Max & Min Resultants</h1>
        <p className="text-muted-foreground">Observe the resultant magnitude extremes when vectors are parallel vs anti-parallel.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        <div className="lg:col-span-1">
          <Card className="h-full">
            <Panel title="Magnitudes">
              <div className="space-y-8">
                <div className="p-4 bg-red-50/50 rounded-xl border border-red-100">
                  <LabeledSlider label="Vector P" value={pMag} min={20} max={200} onChange={setPMag} accentClass="accent-red-500" />
                </div>
                <div className="p-4 bg-teal-50/50 rounded-xl border border-teal-100">
                  <LabeledSlider label="Vector Q" value={qMag} min={20} max={200} onChange={setQMag} accentClass="accent-teal-500" />
                </div>
              </div>
            </Panel>
          </Card>
        </div>

        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
            <Card className="h-full flex flex-col">
              <div className="p-4 border-b bg-muted/30">
                <h3 className="font-bold flex justify-between items-center">
                  Maximum Resultant
                  <span className="text-sm font-mono bg-white px-2 py-1 rounded shadow-sm">θ = 0°</span>
                </h3>
              </div>
              <div className="flex-1 p-1 bg-zinc-50/50">
                <canvas ref={canvasMaxRef} className="w-full h-full min-h-[300px]" />
              </div>
              <div className="p-6 border-t bg-amber-50/30">
                <MathFormula className="bg-white">
                  <span className="text-muted-foreground">R_max = |P| + |Q|</span>
                  <span className="font-bold text-amber-600 text-lg">{pMag + qMag}</span>
                </MathFormula>
              </div>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
            <Card className="h-full flex flex-col">
              <div className="p-4 border-b bg-muted/30">
                <h3 className="font-bold flex justify-between items-center">
                  Minimum Resultant
                  <span className="text-sm font-mono bg-white px-2 py-1 rounded shadow-sm">θ = 180°</span>
                </h3>
              </div>
              <div className="flex-1 p-1 bg-zinc-50/50">
                <canvas ref={canvasMinRef} className="w-full h-full min-h-[300px]" />
              </div>
              <div className="p-6 border-t bg-amber-50/30">
                <MathFormula className="bg-white">
                  <span className="text-muted-foreground">R_min = ||P| - |Q||</span>
                  <span className="font-bold text-amber-600 text-lg">{Math.abs(pMag - qMag)}</span>
                </MathFormula>
              </div>
            </Card>
          </motion.div>
        </div>

      </div>
    </Layout>
  );
}
