import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Card, Panel, LabeledSlider, MathFormula, setupHighDPICanvas, drawVector } from "@/components/ui-elements";
import { Play, RotateCcw, Pause } from "lucide-react";
import { motion } from "framer-motion";

export function RiverBoat() {
  const [vBoat, setVBoat] = useState(5);
  const [vStream, setVStream] = useState(3);
  const [width, setWidth] = useState(200);
  const [angle, setAngle] = useState(90); // 90 is straight across
  
  const [isPlaying, setIsPlaying] = useState(false);
  const timeRef = useRef(0);
  const reqRef = useRef<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Derived physics values
  const rad = (angle * Math.PI) / 180;
  const v_bx = vBoat * Math.cos(rad);
  const v_by = vBoat * Math.sin(rad); // Using standard convention, y goes "up" across the river
  
  const v_nx = vStream + v_bx;
  const v_ny = v_by;

  // Cannot cross if moving perfectly parallel or opposite to bank
  const canCross = v_ny > 0;
  const timeToCross = canCross ? width / v_ny : Infinity;
  const drift = canCross ? v_nx * timeToCross : Infinity;
  const pathLen = canCross ? Math.sqrt(width * width + drift * drift) : Infinity;

  // Animation constants
  const CANVAS_LOGICAL_WIDTH = 800;
  const CANVAS_LOGICAL_HEIGHT = 500;
  const RIVER_Y_BOTTOM = 400;
  const RIVER_Y_TOP = 100;
  const SCALE = (RIVER_Y_BOTTOM - RIVER_Y_TOP) / width; // pixels per meter
  
  const START_X = CANVAS_LOGICAL_WIDTH / 2;
  const START_Y = RIVER_Y_BOTTOM;

  const resetSim = () => {
    setIsPlaying(false);
    timeRef.current = 0;
    if (reqRef.current) cancelAnimationFrame(reqRef.current);
    drawFrame();
  };

  const toggleSim = () => {
    if (!canCross) {
      alert("Boat velocity must have a vertical component to cross.");
      return;
    }
    if (isPlaying) {
      setIsPlaying(false);
      if (reqRef.current) cancelAnimationFrame(reqRef.current);
    } else {
      setIsPlaying(true);
      if (timeRef.current >= timeToCross) {
        timeRef.current = 0; // restart if finished
      }
      reqRef.current = requestAnimationFrame(updateFrame);
    }
  };

  const updateFrame = () => {
    // Increment time (dt)
    timeRef.current += 0.05; // speed factor
    if (timeRef.current >= timeToCross) {
      timeRef.current = timeToCross;
      setIsPlaying(false);
      drawFrame();
      return;
    }
    drawFrame();
    reqRef.current = requestAnimationFrame(updateFrame);
  };

  const drawFrame = () => {
    if (!canvasRef.current) return;
    const canvasObj = setupHighDPICanvas(canvasRef.current);
    if (!canvasObj) return;
    
    const { ctx, width: cw, height: ch } = canvasObj;
    ctx.clearRect(0, 0, cw, ch);

    // Draw Land
    ctx.fillStyle = "#f8fafc";
    ctx.fillRect(0, 0, cw, RIVER_Y_TOP);
    ctx.fillRect(0, RIVER_Y_BOTTOM, cw, ch - RIVER_Y_BOTTOM);

    // Draw River
    const gradient = ctx.createLinearGradient(0, RIVER_Y_TOP, 0, RIVER_Y_BOTTOM);
    gradient.addColorStop(0, "#e0f2fe"); // blue-100
    gradient.addColorStop(1, "#bae6fd"); // blue-200
    ctx.fillStyle = gradient;
    ctx.fillRect(0, RIVER_Y_TOP, cw, RIVER_Y_BOTTOM - RIVER_Y_TOP);

    // Draw animated stream lines
    ctx.strokeStyle = "#7dd3fc"; // blue-300
    ctx.lineWidth = 2;
    ctx.setLineDash([20, 30]);
    const offset = (Date.now() / 20 * vStream) % 50;
    for (let y = RIVER_Y_TOP + 30; y < RIVER_Y_BOTTOM; y += 40) {
      ctx.beginPath();
      ctx.moveTo(-offset, y);
      ctx.lineTo(cw, y);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Calculate current position
    const t = timeRef.current;
    const currentX = START_X + (v_nx * t * SCALE);
    const currentY = START_Y - (v_ny * t * SCALE); // Minus because canvas Y is down

    // Draw Path Trace (dashed line)
    ctx.beginPath();
    ctx.moveTo(START_X, START_Y);
    ctx.lineTo(currentX, currentY);
    ctx.strokeStyle = "#94a3b8"; // slate-400
    ctx.setLineDash([5, 5]);
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw Boat (simple dot/circle)
    ctx.beginPath();
    ctx.arc(currentX, currentY, 8, 0, Math.PI * 2);
    ctx.fillStyle = "#1e293b";
    ctx.fill();
    ctx.strokeStyle = "white";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw Velocity Vectors originating from the boat
    const V_SCALE = 15; // Visual length multiplier for velocity vectors
    drawVector(ctx, currentX, currentY, currentX + v_bx * V_SCALE, currentY - v_by * V_SCALE, "#3b82f6", "v_b");
    drawVector(ctx, currentX, currentY, currentX + vStream * V_SCALE, currentY, "#10b981", "v_s");
    drawVector(ctx, currentX, currentY, currentX + v_nx * V_SCALE, currentY - v_ny * V_SCALE, "#f97316", "v_net");
  };

  // Draw initial frame and when dependencies change (only if paused)
  useEffect(() => {
    if (!isPlaying) {
      drawFrame();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vBoat, vStream, width, angle]);

  // Clean up animation on unmount
  useEffect(() => {
    return () => {
      if (reqRef.current) cancelAnimationFrame(reqRef.current);
    };
  }, []);

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold mb-2">River Boat Problem</h1>
        <p className="text-muted-foreground">Relative velocity in 2D kinematics. Observe how river flow affects trajectory and crossing time.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card className="p-0 overflow-hidden relative">
            <div className="absolute top-4 left-4 z-10 flex gap-2">
              <button 
                onClick={toggleSim}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all font-semibold text-sm"
              >
                {isPlaying ? <><Pause size={16}/> Pause</> : <><Play size={16}/> Play</>}
              </button>
              <button 
                onClick={resetSim}
                className="flex items-center gap-2 px-4 py-2 bg-card text-foreground border border-border rounded-full shadow-sm hover:bg-muted active:scale-95 transition-all font-semibold text-sm"
              >
                <RotateCcw size={16}/> Reset
              </button>
            </div>
            
            <div className="h-[500px] bg-slate-50 relative">
              <canvas ref={canvasRef} className="w-full h-full" />
              {/* Overlay labels purely for aesthetic */}
              <div className="absolute top-[80px] right-6 text-sm font-mono text-slate-400 font-bold tracking-widest">TARGET BANK</div>
              <div className="absolute bottom-[80px] right-6 text-sm font-mono text-slate-400 font-bold tracking-widest">START BANK</div>
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <MathFormula className="flex-col items-start gap-1">
              <span className="text-xs text-muted-foreground font-semibold">CROSSING TIME</span>
              <span className="text-xl font-bold text-foreground">
                {canCross ? `${timeToCross.toFixed(1)} s` : "Never"}
              </span>
            </MathFormula>
            <MathFormula className="flex-col items-start gap-1 border-b-4 border-b-[#f97316]">
              <span className="text-xs text-muted-foreground font-semibold">DOWNSTREAM DRIFT</span>
              <span className="text-xl font-bold text-foreground">
                {canCross ? `${drift.toFixed(1)} m` : "N/A"}
              </span>
            </MathFormula>
            <MathFormula className="flex-col items-start gap-1">
              <span className="text-xs text-muted-foreground font-semibold">TOTAL DISTANCE</span>
              <span className="text-xl font-bold text-foreground">
                {canCross ? `${pathLen.toFixed(1)} m` : "N/A"}
              </span>
            </MathFormula>
          </div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="h-full">
            <Panel title="Environment">
              <div className="space-y-8">
                <div className="space-y-6">
                  <h4 className="text-sm font-bold text-slate-500 uppercase tracking-wider border-b pb-2">Velocities</h4>
                  <LabeledSlider label="Boat Velocity" value={vBoat} min={2} max={15} step={0.5} unit=" m/s" onChange={setVBoat} accentClass="accent-blue-500" />
                  <LabeledSlider label="Stream Velocity" value={vStream} min={0} max={10} step={0.5} unit=" m/s" onChange={setVStream} accentClass="accent-emerald-500" />
                </div>
                
                <div className="space-y-6 pt-6 border-t">
                  <h4 className="text-sm font-bold text-slate-500 uppercase tracking-wider border-b pb-2">Geometry</h4>
                  <LabeledSlider label="River Width" value={width} min={100} max={400} step={10} unit=" m" onChange={setWidth} accentClass="accent-slate-800" />
                  <LabeledSlider label="Heading Angle" value={angle} min={10} max={170} step={5} unit="°" onChange={setAngle} accentClass="accent-orange-500" />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    * 90° points straight across the river. Angles &lt; 90° point downstream, &gt; 90° point upstream.
                  </p>
                </div>
              </div>
            </Panel>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
