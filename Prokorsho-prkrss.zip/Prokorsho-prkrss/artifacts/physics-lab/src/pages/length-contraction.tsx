import { Layout } from "@/components/layout";

export function LengthContraction() {
  return (
    <Layout>
      <div className="-mx-4 sm:-mx-6 lg:-mx-8 -my-8 lg:-my-12" style={{ height: "calc(100vh - 64px)" }}>
        <iframe
          src="/sims/length-contraction.html"
          className="w-full h-full border-0"
          title="দৈর্ঘ্য সংকোচন — বিশেষ আপেক্ষিকতা"
        />
      </div>
    </Layout>
  );
}
