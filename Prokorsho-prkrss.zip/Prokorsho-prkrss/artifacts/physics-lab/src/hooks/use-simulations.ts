import { useState } from "react";
import { MoveRight, TrendingUp, Maximize2, Waves, BookOpen, Zap, CloudRain, Cpu, Train, Weight, GitFork, Activity, Layers } from "lucide-react";

// Static data provider for the physics simulations
// Acts as a local mock for a generic data hook since this app is purely frontend

export type Simulation = {
  id: string;
  title: string;
  description: string;
  href: string;
  icon: React.ElementType;
};

const SIMULATIONS: Simulation[] = [
  {
    id: "vector-addition",
    title: "Vector Addition",
    description: "Explore the triangle and parallelogram laws by graphically adding two vectors together.",
    href: "/vector-addition",
    icon: MoveRight
  },
  {
    id: "vector-components",
    title: "Vector Components",
    description: "Decompose a single vector into its X and Y Cartesian components using trigonometry.",
    href: "/vector-components",
    icon: TrendingUp
  },
  {
    id: "max-min",
    title: "Max & Min Resultants",
    description: "Analyze how the angle between vectors produces maximum and minimum possible resultants.",
    href: "/max-min-resultant",
    icon: Maximize2
  },
  {
    id: "river-boat",
    title: "নদী ও নৌকা",
    description: "An animated kinematics simulation calculating relative velocities across a flowing stream.",
    href: "/river-boat",
    icon: Waves
  },
  {
    id: "vector-problem-01",
    title: "ভেক্টর সমস্যা ০১",
    description: "",
    href: "/vector-problem-01",
    icon: BookOpen
  },
  {
    id: "vector-problem-02",
    title: "ভেক্টর সমস্যা ০২",
    description: "",
    href: "/vector-problem-02",
    icon: BookOpen
  },
  {
    id: "vector-problem-03",
    title: "ভেক্টর সমস্যা ০৩",
    description: "",
    href: "/vector-problem-03",
    icon: BookOpen
  },
  {
    id: "vector-problem-04",
    title: "ভেক্টর সমস্যা ০৪",
    description: "",
    href: "/vector-problem-04",
    icon: BookOpen
  },
  {
    id: "rectangular-component",
    title: "লম্বাংশ উপপাদ্য সমস্যা",
    description: "",
    href: "/rectangular-component",
    icon: Zap
  },
  {
    id: "rain-umbrella",
    title: "বৃষ্টি-ছাতা ভিজ্যুয়ালাইজেশন",
    description: "",
    href: "/rain-umbrella",
    icon: CloudRain
  },
  {
    id: "circuit-maker",
    title: "তড়িৎ বর্তনী নির্মাতা",
    description: "",
    href: "/circuit-maker",
    icon: Cpu
  },
  {
    id: "relative-velocity-trains",
    title: "আপেক্ষিক বেগ — দুটি ট্রেন",
    description: "",
    href: "/relative-velocity-trains",
    icon: Train
  },
  {
    id: "atwood-machine",
    title: "অ্যাটউড মেশিন",
    description: "",
    href: "/atwood-machine",
    icon: Weight
  },
  {
    id: "three-pulley",
    title: "তিন পুলি সংযোগ",
    description: "",
    href: "/three-pulley",
    icon: GitFork
  },
  {
    id: "atwood-simulator",
    title: "অ্যাটউড সিমুলেটর",
    description: "",
    href: "/atwood-simulator",
    icon: Activity
  },
  {
    id: "compound-atwood",
    title: "যৌগিক অ্যাটউড মেশিন",
    description: "",
    href: "/compound-atwood",
    icon: Layers
  },
];

export function useSimulations() {
  const [simulations] = useState<Simulation[]>(SIMULATIONS);
  
  return {
    simulations,
    getSimulation: (id: string) => simulations.find(s => s.id === id)
  };
}
