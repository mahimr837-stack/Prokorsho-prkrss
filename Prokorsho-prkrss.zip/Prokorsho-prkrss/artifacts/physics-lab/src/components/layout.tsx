import React from "react";
import { Link } from "wouter";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <nav className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group outline-none">
            <img
              src="/logo.png"
              alt="বিজ্ঞান ল্যাব"
              className="w-16 h-16 object-contain group-hover:scale-105 transition-transform duration-300"
            />
            <span className="font-display font-bold text-lg tracking-tight group-hover:opacity-80 transition-opacity">
              বিজ্ঞান ল্যাব
            </span>
          </Link>
          <span className="text-sm text-muted-foreground italic">created by Mahe</span>
        </div>
      </nav>
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        {children}
      </main>
    </div>
  );
}
