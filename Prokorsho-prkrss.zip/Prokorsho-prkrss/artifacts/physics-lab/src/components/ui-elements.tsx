import React from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ----------------------------------------------------------------------
// Reusable Layout Components
// ----------------------------------------------------------------------

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("bg-card rounded-2xl border border-border shadow-sm overflow-hidden", className)}>
      {children}
    </div>
  );
}

export function Panel({ className, title, children }: { className?: string; title?: string; children: React.ReactNode }) {
  return (
    <div className={cn("flex flex-col gap-6 p-6 lg:p-8", className)}>
      {title && <h3 className="text-lg font-bold border-b pb-4 mb-2">{title}</h3>}
      {children}
    </div>
  );
}

// ----------------------------------------------------------------------
// Form Controls
// ----------------------------------------------------------------------

type SliderProps = {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (val: number) => void;
  accentClass?: string;
};

export function LabeledSlider({ label, value, min, max, step = 1, unit = "", onChange, accentClass }: SliderProps) {
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <label className="text-sm font-semibold text-foreground tracking-tight">{label}</label>
        <span className="text-sm font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded-md">
          {value}{unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className={cn(accentClass)}
      />
      <div className="flex justify-between text-xs text-muted-foreground font-mono">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

export function MathFormula({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("px-4 py-3 rounded-xl bg-muted/50 border border-border/50 text-sm font-mono flex items-center justify-between", className)}>
      {children}
    </div>
  );
}

// ----------------------------------------------------------------------
// Canvas Drawing Utilities
// ----------------------------------------------------------------------

export function setupHighDPICanvas(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;

  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();

  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  
  ctx.scale(dpr, dpr);
  
  return { ctx, width: rect.width, height: rect.height };
}

export function drawGrid(ctx: CanvasRenderingContext2D, width: number, height: number, spacing = 50) {
  ctx.strokeStyle = "#f1f5f9"; // light grid
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 0; x <= width; x += spacing) {
    ctx.moveTo(x, 0); ctx.lineTo(x, height);
  }
  for (let y = 0; y <= height; y += spacing) {
    ctx.moveTo(0, y); ctx.lineTo(width, y);
  }
  ctx.stroke();

  // Draw axes crossing at center
  ctx.strokeStyle = "#e2e8f0";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(width / 2, 0); ctx.lineTo(width / 2, height);
  ctx.moveTo(0, height / 2); ctx.lineTo(width, height / 2);
  ctx.stroke();
}

export function drawVector(
  ctx: CanvasRenderingContext2D,
  fromX: number,
  fromY: number,
  toX: number,
  toY: number,
  color: string,
  label?: string,
  isDashed: boolean = false
) {
  const headlen = 12;
  const dx = toX - fromX;
  const dy = toY - fromY;
  const angle = Math.atan2(dy, dx);
  const length = Math.sqrt(dx * dx + dy * dy);

  if (length < 1) return; // Too short to draw

  ctx.beginPath();
  ctx.setLineDash(isDashed ? [6, 6] : []);
  ctx.moveTo(fromX, fromY);
  ctx.lineTo(toX, toY);
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  if (!isDashed) {
    ctx.beginPath();
    ctx.setLineDash([]);
    ctx.moveTo(toX, toY);
    ctx.lineTo(toX - headlen * Math.cos(angle - Math.PI / 6), toY - headlen * Math.sin(angle - Math.PI / 6));
    ctx.lineTo(toX - headlen * Math.cos(angle + Math.PI / 6), toY - headlen * Math.sin(angle + Math.PI / 6));
    ctx.lineTo(toX, toY);
    ctx.fillStyle = color;
    ctx.fill();
  }

  ctx.setLineDash([]);

  if (label) {
    ctx.fillStyle = color;
    ctx.font = "600 14px 'JetBrains Mono', monospace";
    const labelDist = 15;
    ctx.fillText(label, toX + labelDist * Math.cos(angle), toY + labelDist * Math.sin(angle));
  }
}
