import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { Home } from "@/pages/home";
import { VectorAddition } from "@/pages/vector-addition";
import { VectorComponents } from "@/pages/vector-components";
import { MaxMinResultant } from "@/pages/max-min-resultant";
import { RiverBoat } from "@/pages/river-boat";
import { VectorProblem01 } from "@/pages/vector-problem-01";
import { VectorProblem02 } from "@/pages/vector-problem-02";
import { VectorProblem03 } from "@/pages/vector-problem-03";
import { VectorProblem04 } from "@/pages/vector-problem-04";
import { RectangularComponent } from "@/pages/rectangular-component";
import { RainUmbrella } from "@/pages/rain-umbrella";
import { CircuitMaker } from "@/pages/circuit-maker";
import { RelativeVelocityTrains } from "@/pages/relative-velocity-trains";
import { AtwoodMachine } from "@/pages/atwood-machine";
import { ThreePulley } from "@/pages/three-pulley";
import { AtwoodSimulator } from "@/pages/atwood-simulator";
import { CompoundAtwood } from "@/pages/compound-atwood";
import { VectorTypes } from "@/pages/vector-types";
import { LengthContraction } from "@/pages/length-contraction";
import { RelativeMass } from "@/pages/relative-mass";
import { PunnettSquare } from "@/pages/punnett-square";
import { TitrationSimulator } from "@/pages/titration-simulator";
import { IdealGasSim } from "@/pages/ideal-gas-sim";
import { ChainIsomerism } from "@/pages/chain-isomerism";
import { TrigUnitCircle } from "@/pages/trig-unit-circle";
import { Hybridization3D } from "@/pages/hybridization-3d";
import { GalvanicCell } from "@/pages/galvanic-cell";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/vector-addition" component={VectorAddition} />
      <Route path="/vector-components" component={VectorComponents} />
      <Route path="/max-min-resultant" component={MaxMinResultant} />
      <Route path="/river-boat" component={RiverBoat} />
      <Route path="/vector-problem-01" component={VectorProblem01} />
      <Route path="/vector-problem-02" component={VectorProblem02} />
      <Route path="/vector-problem-03" component={VectorProblem03} />
      <Route path="/vector-problem-04" component={VectorProblem04} />
      <Route path="/rectangular-component" component={RectangularComponent} />
      <Route path="/rain-umbrella" component={RainUmbrella} />
      <Route path="/circuit-maker" component={CircuitMaker} />
      <Route path="/relative-velocity-trains" component={RelativeVelocityTrains} />
      <Route path="/atwood-machine" component={AtwoodMachine} />
      <Route path="/three-pulley" component={ThreePulley} />
      <Route path="/atwood-simulator" component={AtwoodSimulator} />
      <Route path="/compound-atwood" component={CompoundAtwood} />
      <Route path="/vector-types" component={VectorTypes} />
      <Route path="/length-contraction" component={LengthContraction} />
      <Route path="/relative-mass" component={RelativeMass} />
      <Route path="/punnett-square" component={PunnettSquare} />
      <Route path="/titration-simulator" component={TitrationSimulator} />
      <Route path="/ideal-gas-sim" component={IdealGasSim} />
      <Route path="/chain-isomerism" component={ChainIsomerism} />
      <Route path="/trig-unit-circle" component={TrigUnitCircle} />
      <Route path="/hybridization-3d" component={Hybridization3D} />
      <Route path="/galvanic-cell" component={GalvanicCell} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
